export interface IAuthServiceLogin{
    email :string
    password: string
}