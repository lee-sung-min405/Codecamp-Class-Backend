import { Injectable } from '@nestjs/common';
import { POINT_TRANSACTION_STATUS_ENUM, PointTransaction } from './entities/pointTransaction.entity';
import { IPointsTransactionsServiceCreate } from './interfaces/points-transactions-service.interface';
import { InjectRepository } from '@nestjs/typeorm';
import { DataSource, Repository } from 'typeorm';
import { User } from '../users/entities/user.entity';

@Injectable()
export class PointsTransactionsService {
  constructor(
    @InjectRepository(PointTransaction)
    private readonly pointsTransactionsRepository: Repository<PointTransaction>,

    @InjectRepository(User)
    private readonly usersRepository: Repository<User>,

    private readonly dataSource: DataSource,
  ) {}

  async create({
    impUid,
    amount,
    user: _user,
  }: IPointsTransactionsServiceCreate): Promise<PointTransaction> {
    // 디버깅 로그 추가
    console.log('1. PointTransaction 개체 생성', impUid, amount, _user.userId);

    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction("SERIALIZABLE");
    try{
         // 1. PointTransaction 객체 생성
      const pointTransaction = this.pointsTransactionsRepository.create({
      impUid,
      amount,
      user: _user.userId,  // 관계 설정을 위해 user 객체를 포함
      status: POINT_TRANSACTION_STATUS_ENUM.PAYMENT,
    });

    // 디버깅 로그 추가
    console.log('2. PointTransaction 개체 저장 중', impUid, amount, _user, pointTransaction);

    // 2. PointTransaction 테이블에 거래기록 1줄 생성
    // await this.pointsTransactionsRepository.save(pointTransaction);
    await queryRunner.manager.save(pointTransaction);

    // 디버깅 로그 추가
    console.log('3. ID로 사용자 찾기:',  _user.userId);

    // 3. 유저의 돈 찾아서 업데이트하기
    // 숫자일 때 가능 => 숫자가 아니면?/ (ex,좌석 등) 직접 lock 걸기 service 참조
    const id = _user.id
    await queryRunner.manager.increment(
      User,
      {id},
      'point',
      amount,
    )

    await queryRunner.commitTransaction();
    
    // 디버깅 로그 추가
    console.log('5. 사용자 포인트 업데이트');
    
    // 4. 최종결과 브라우저에 돌려주기
    return pointTransaction;

    }catch(error){
      await queryRunner.rollbackTransaction();
 
    }
    finally{
      await queryRunner.release();
    }

 
  }
}
