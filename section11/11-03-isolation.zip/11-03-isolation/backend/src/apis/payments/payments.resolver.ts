import { Controller, Get, Post, Body } from '@nestjs/common';
import { PaymentsService } from './payments.service';
import { Payment } from './entities/payment.entity';

@Controller('/payments')
export class PaymentsResolver {
  constructor(private readonly paymentsService: PaymentsService) {}

  @Post()
  async createPayment(@Body('amount') amount: number): Promise<Payment> {
    return this.paymentsService.create({ amount });
  }

  @Get()
  async fetchPayments(): Promise<Payment[]> {
    return this.paymentsService.findAll();
  }  
}
