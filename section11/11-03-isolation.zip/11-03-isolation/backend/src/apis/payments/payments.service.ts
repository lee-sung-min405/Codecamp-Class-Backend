import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DataSource, Repository } from 'typeorm';
import { Payment } from './entities/payment.entity';

@Injectable()
export class PaymentsService {
  constructor(
    @InjectRepository(Payment)
    private readonly paymentsRepository: Repository<Payment>, // Payment 엔티티를 위한 리포지토리 주입

    private readonly dataSource: DataSource, // 데이터베이스 연결을 위한 DataSource 주입
  ) {}

  // 모든 결제 데이터를 조회하는 메서드
  async findAll(): Promise<Payment[]> {
    const queryRunner = this.dataSource.createQueryRunner(); // 쿼리 러너 생성
    await queryRunner.connect(); // 데이터베이스에 연결
    await queryRunner.startTransaction('SERIALIZABLE'); // 트랜잭션 시작
    try {
      const payments = await queryRunner.manager.find(Payment); // Payment 엔티티의 모든 데이터 조회
      await queryRunner.commitTransaction(); // 트랜잭션 커밋
      return payments; // 조회된 데이터 반환
    } catch (error) {
      await queryRunner.rollbackTransaction(); // 에러 발생 시 트랜잭션 롤백
      throw error; // 에러 던지기
    } finally {
      await queryRunner.release(); // 쿼리 러너 해제
    }
  }

  // 새로운 결제 데이터를 생성하는 메서드
  async create({ amount }): Promise<Payment> {
    const queryRunner = this.dataSource.createQueryRunner(); // 쿼리 러너 생성
    await queryRunner.connect(); // 데이터베이스에 연결
    await queryRunner.startTransaction('SERIALIZABLE'); // 트랜잭션 시작
    try {
      const newPayment = this.paymentsRepository.create({ amount }); // 새로운 Payment 객체 생성
      await queryRunner.manager.save(newPayment); // 새로운 Payment 객체를 데이터베이스에 저장
      await queryRunner.commitTransaction(); // 트랜잭션 커밋
      return newPayment; // 생성된 Payment 객체 반환
    } catch (error) {
      await queryRunner.rollbackTransaction(); // 에러 발생 시 트랜잭션 롤백
      throw error; // 에러 던지기
    } finally {
      await queryRunner.release(); // 쿼리 러너 해제
    }
  }
}
